-- ══════════════════════════════════════════════════════
-- InnovaAFRIC · Schema PostgreSQL / Supabase
-- Versión 1.0 · Mayo 2026
-- ══════════════════════════════════════════════════════
-- Ejecutar en Supabase SQL Editor o psql:
--   psql $DATABASE_URL -f schema.sql

-- ── EXTENSIONES ────────────────────────────────────────
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ══════════════════════════════════════════════════════
-- 1. USUARIOS
-- ══════════════════════════════════════════════════════
CREATE TABLE users (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email         TEXT UNIQUE NOT NULL,
  phone         TEXT,
  full_name     TEXT NOT NULL,
  role          TEXT NOT NULL CHECK (role IN ('cliente','circular','rider','proveedor','comercio','admin')),
  country       TEXT DEFAULT 'GQ',
  city          TEXT,
  lang          TEXT DEFAULT 'es' CHECK (lang IN ('es','en','fr')),
  avatar_url    TEXT,
  is_verified   BOOLEAN DEFAULT FALSE,
  is_active     BOOLEAN DEFAULT TRUE,
  referral_code TEXT UNIQUE DEFAULT substring(md5(random()::text), 1, 8),
  referred_by   UUID REFERENCES users(id),
  created_at    TIMESTAMPTZ DEFAULT NOW(),
  updated_at    TIMESTAMPTZ DEFAULT NOW()
);

-- KYC levels
CREATE TABLE kyc (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  level       INTEGER DEFAULT 0 CHECK (level IN (0,1,2)),
  -- 0=Básico €200 · 1=Estándar €2K · 2=Premium ilimitado
  doc_type    TEXT,
  doc_number  TEXT,
  doc_url     TEXT,
  selfie_url  TEXT,
  status      TEXT DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
  reviewed_by UUID REFERENCES users(id),
  reviewed_at TIMESTAMPTZ,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ══════════════════════════════════════════════════════
-- 2. WALLETS Y FINANZAS (XenderMoney)
-- ══════════════════════════════════════════════════════
CREATE TABLE wallets (
  id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id    UUID UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  eur        NUMERIC(15,4) DEFAULT 0 CHECK (eur >= 0),
  xaf        NUMERIC(15,2) DEFAULT 0 CHECK (xaf >= 0),
  xof        NUMERIC(15,2) DEFAULT 0 CHECK (xof >= 0),
  usd        NUMERIC(15,4) DEFAULT 0 CHECK (usd >= 0),
  points     INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE transactions (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id       UUID REFERENCES users(id),
  type          TEXT NOT NULL CHECK (type IN ('send','receive','p2p','qr_pay','cashout','topup','refund','points_earn','points_redeem')),
  amount        NUMERIC(15,4) NOT NULL,
  currency      TEXT NOT NULL CHECK (currency IN ('EUR','USD','XAF','XOF')),
  amount_recv   NUMERIC(15,4),
  currency_recv TEXT CHECK (currency_recv IN ('EUR','USD','XAF','XOF')),
  fee           NUMERIC(15,4) DEFAULT 0,
  rate          NUMERIC(12,6),
  status        TEXT DEFAULT 'pending' CHECK (status IN ('pending','processing','completed','failed','refunded')),
  ref_code      TEXT UNIQUE DEFAULT 'TXN-' || upper(substring(md5(random()::text), 1, 10)),
  recipient_id  UUID REFERENCES users(id),
  recipient_phone TEXT,
  description   TEXT,
  metadata      JSONB,
  created_at    TIMESTAMPTZ DEFAULT NOW(),
  completed_at  TIMESTAMPTZ
);
CREATE INDEX idx_txn_user ON transactions(user_id);
CREATE INDEX idx_txn_status ON transactions(status);
CREATE INDEX idx_txn_created ON transactions(created_at DESC);

-- Envíos recurrentes
CREATE TABLE recurring_transfers (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id       UUID REFERENCES users(id) ON DELETE CASCADE,
  recipient_id  UUID REFERENCES users(id),
  recipient_phone TEXT,
  amount        NUMERIC(15,4) NOT NULL,
  currency      TEXT NOT NULL,
  currency_recv TEXT NOT NULL,
  frequency     TEXT NOT NULL CHECK (frequency IN ('weekly','biweekly','monthly')),
  next_run      DATE NOT NULL,
  is_active     BOOLEAN DEFAULT TRUE,
  runs_count    INTEGER DEFAULT 0,
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

-- Tasas de cambio históricas
CREATE TABLE exchange_rates (
  id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  from_curr  TEXT NOT NULL,
  to_curr    TEXT NOT NULL,
  rate       NUMERIC(12,6) NOT NULL,
  source     TEXT DEFAULT 'ecb',
  date       DATE DEFAULT CURRENT_DATE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE UNIQUE INDEX idx_rates_date ON exchange_rates(from_curr, to_curr, date);

-- ══════════════════════════════════════════════════════
-- 3. XENDERSHOP — Productos y pedidos
-- ══════════════════════════════════════════════════════
CREATE TABLE products (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  supplier_id   UUID REFERENCES users(id),
  name          TEXT NOT NULL,
  description   TEXT,
  category      TEXT CHECK (category IN ('electronica','moda','hogar','belleza','alimentacion','otros')),
  price_eur     NUMERIC(10,2) NOT NULL,
  price_xaf     NUMERIC(12,0),
  stock         INTEGER DEFAULT 0,
  images        TEXT[] DEFAULT '{}',
  is_ce_certified BOOLEAN DEFAULT FALSE,
  ce_cert_url   TEXT,
  weight_kg     NUMERIC(6,3),
  origin_country TEXT DEFAULT 'CN',
  is_active     BOOLEAN DEFAULT TRUE,
  is_flash_sale BOOLEAN DEFAULT FALSE,
  flash_price   NUMERIC(10,2),
  flash_ends_at TIMESTAMPTZ,
  rating        NUMERIC(3,2) DEFAULT 0,
  review_count  INTEGER DEFAULT 0,
  created_at    TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_products_category ON products(category);
CREATE INDEX idx_products_flash ON products(is_flash_sale, flash_ends_at);

CREATE TABLE orders (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id       UUID REFERENCES users(id),
  type          TEXT DEFAULT 'shop' CHECK (type IN ('shop','bigshop')),
  status        TEXT DEFAULT 'pending' CHECK (status IN ('pending','confirmed','processing','shipped','out_for_delivery','delivered','cancelled','refunded')),
  total_eur     NUMERIC(10,2),
  total_xaf     NUMERIC(12,0),
  currency_paid TEXT DEFAULT 'EUR',
  delivery_address JSONB,
  circular_id   UUID REFERENCES users(id),
  rider_id      UUID REFERENCES users(id),
  tracking_code TEXT UNIQUE,
  notes         TEXT,
  photo_proof   TEXT,
  signature_url TEXT,
  delivered_at  TIMESTAMPTZ,
  created_at    TIMESTAMPTZ DEFAULT NOW(),
  updated_at    TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_orders_user ON orders(user_id);
CREATE INDEX idx_orders_status ON orders(status);

CREATE TABLE order_items (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id    UUID REFERENCES orders(id) ON DELETE CASCADE,
  product_id  UUID REFERENCES products(id),
  name        TEXT NOT NULL,
  qty         INTEGER NOT NULL,
  price       NUMERIC(10,2) NOT NULL,
  currency    TEXT DEFAULT 'EUR'
);

-- Tracking de envíos (Asia → España → África)
CREATE TABLE shipment_tracking (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id    UUID REFERENCES orders(id) ON DELETE CASCADE,
  status      TEXT NOT NULL CHECK (status IN ('ordered','in_production','shipped_asia','arrived_spain','ce_inspection','shipped_africa','arrived_country','out_delivery','delivered')),
  location    TEXT,
  description TEXT,
  timestamp   TIMESTAMPTZ DEFAULT NOW()
);

-- Reseñas de productos
CREATE TABLE reviews (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  product_id  UUID REFERENCES products(id) ON DELETE CASCADE,
  user_id     UUID REFERENCES users(id) ON DELETE CASCADE,
  order_id    UUID REFERENCES orders(id),
  rating      INTEGER CHECK (rating BETWEEN 1 AND 5),
  comment     TEXT,
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(product_id, user_id)
);

-- ══════════════════════════════════════════════════════
-- 4. XENDERBIGSHOP — Grocery
-- ══════════════════════════════════════════════════════
CREATE TABLE grocery_items (
  id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name       TEXT NOT NULL,
  category   TEXT,
  price_xaf  NUMERIC(10,0) NOT NULL,
  unit       TEXT DEFAULT 'unidad',
  image_url  TEXT,
  is_fresh   BOOLEAN DEFAULT FALSE,
  is_local   BOOLEAN DEFAULT FALSE,
  is_active  BOOLEAN DEFAULT TRUE,
  stock      INTEGER DEFAULT 100
);

-- Pedidos programados
CREATE TABLE scheduled_orders (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id       UUID REFERENCES users(id),
  items         JSONB NOT NULL,
  total_xaf     NUMERIC(12,0),
  address       JSONB,
  scheduled_date DATE NOT NULL,
  time_slot     TEXT NOT NULL,
  status        TEXT DEFAULT 'active' CHECK (status IN ('active','completed','cancelled')),
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

-- ══════════════════════════════════════════════════════
-- 5. CIRCULARES AUTORIZADAS
-- ══════════════════════════════════════════════════════
CREATE TABLE circulares (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID UNIQUE REFERENCES users(id),
  territory       TEXT NOT NULL,
  country         TEXT NOT NULL,
  city            TEXT NOT NULL,
  investment_tier TEXT CHECK (investment_tier IN ('basic','standard','premium','enterprise')),
  status          TEXT DEFAULT 'pending' CHECK (status IN ('pending','active','suspended','cancelled')),
  commission_pct  NUMERIC(4,2) DEFAULT 1.0,
  monthly_target  NUMERIC(12,0),
  zones           TEXT[],
  kit_delivered   BOOLEAN DEFAULT FALSE,
  training_done   BOOLEAN DEFAULT FALSE,
  activated_at    TIMESTAMPTZ,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Comisiones de circulares
CREATE TABLE circular_commissions (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  circular_id  UUID REFERENCES circulares(id),
  txn_id       UUID REFERENCES transactions(id),
  order_id     UUID REFERENCES orders(id),
  amount       NUMERIC(10,4) NOT NULL,
  currency     TEXT DEFAULT 'EUR',
  type         TEXT CHECK (type IN ('money','shop','bigshop','delivery','qr')),
  month        DATE DEFAULT date_trunc('month', CURRENT_DATE),
  paid_at      TIMESTAMPTZ,
  created_at   TIMESTAMPTZ DEFAULT NOW()
);

-- ══════════════════════════════════════════════════════
-- 6. RIDERS
-- ══════════════════════════════════════════════════════
CREATE TABLE riders (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id       UUID UNIQUE REFERENCES users(id),
  circular_id   UUID REFERENCES circulares(id),
  vehicle_type  TEXT CHECK (vehicle_type IN ('moto','bicicleta','coche','furgoneta')),
  vehicle_plate TEXT,
  license_url   TEXT,
  insurance_url TEXT,
  tier          TEXT DEFAULT 'bronze' CHECK (tier IN ('bronze','silver','gold')),
  deliveries    INTEGER DEFAULT 0,
  rating        NUMERIC(3,2) DEFAULT 5.0,
  is_online     BOOLEAN DEFAULT FALSE,
  last_location JSONB,
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE deliveries (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id        UUID REFERENCES orders(id),
  rider_id        UUID REFERENCES riders(id),
  status          TEXT DEFAULT 'assigned' CHECK (status IN ('assigned','picked_up','on_way','delivered','failed')),
  pickup_address  JSONB,
  dropoff_address JSONB,
  distance_km     NUMERIC(6,2),
  fee             NUMERIC(8,2) DEFAULT 3.00,
  tip             NUMERIC(8,2) DEFAULT 0,
  photo_proof     TEXT,
  signature_url   TEXT,
  rating          INTEGER CHECK (rating BETWEEN 1 AND 5),
  assigned_at     TIMESTAMPTZ DEFAULT NOW(),
  delivered_at    TIMESTAMPTZ
);

-- Bonos mensuales de riders
CREATE TABLE rider_bonuses (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  rider_id     UUID REFERENCES riders(id),
  month        DATE DEFAULT date_trunc('month', CURRENT_DATE),
  deliveries   INTEGER,
  tier         TEXT,
  base_amount  NUMERIC(10,2),
  bonus_pct    NUMERIC(4,2),
  bonus_amount NUMERIC(10,2),
  total        NUMERIC(10,2),
  paid_at      TIMESTAMPTZ,
  created_at   TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(rider_id, month)
);

-- ══════════════════════════════════════════════════════
-- 7. COMERCIOS QR
-- ══════════════════════════════════════════════════════
CREATE TABLE merchants (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id      UUID UNIQUE REFERENCES users(id),
  circular_id  UUID REFERENCES circulares(id),
  name         TEXT NOT NULL,
  category     TEXT,
  address      TEXT,
  qr_code      TEXT UNIQUE DEFAULT 'COM-' || upper(substring(md5(random()::text), 1, 6)),
  is_active    BOOLEAN DEFAULT TRUE,
  created_at   TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE qr_payments (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  merchant_id UUID REFERENCES merchants(id),
  user_id     UUID REFERENCES users(id),
  amount      NUMERIC(12,0) NOT NULL,
  currency    TEXT DEFAULT 'XAF',
  status      TEXT DEFAULT 'completed',
  ref         TEXT UNIQUE DEFAULT 'QR-' || upper(substring(md5(random()::text), 1, 8)),
  created_at  TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_qr_merchant ON qr_payments(merchant_id);

-- ══════════════════════════════════════════════════════
-- 8. PUNTOS Y REFERIDOS
-- ══════════════════════════════════════════════════════
CREATE TABLE points_log (
  id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id    UUID REFERENCES users(id),
  amount     INTEGER NOT NULL,
  type       TEXT CHECK (type IN ('earn','redeem')),
  source     TEXT CHECK (source IN ('send','shop','bigshop','qr','referral','bonus')),
  ref_id     UUID,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE referrals (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  referrer_id UUID REFERENCES users(id),
  referred_id UUID REFERENCES users(id),
  reward_eur  NUMERIC(6,2) DEFAULT 5.00,
  paid        BOOLEAN DEFAULT FALSE,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ══════════════════════════════════════════════════════
-- 9. NOTIFICACIONES
-- ══════════════════════════════════════════════════════
CREATE TABLE notifications (
  id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id    UUID REFERENCES users(id) ON DELETE CASCADE,
  type       TEXT NOT NULL,
  title_es   TEXT,
  title_en   TEXT,
  title_fr   TEXT,
  body_es    TEXT,
  body_en    TEXT,
  body_fr    TEXT,
  data       JSONB,
  is_read    BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_notif_user ON notifications(user_id, is_read);

-- ══════════════════════════════════════════════════════
-- 10. PROVEEDORES
-- ══════════════════════════════════════════════════════
CREATE TABLE suppliers (
  id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id        UUID UNIQUE REFERENCES users(id),
  company_name   TEXT NOT NULL,
  country        TEXT DEFAULT 'CN',
  contact_email  TEXT,
  contact_phone  TEXT,
  is_ce_approved BOOLEAN DEFAULT FALSE,
  payment_iban   TEXT,
  bank_account   JSONB,
  created_at     TIMESTAMPTZ DEFAULT NOW()
);

-- ══════════════════════════════════════════════════════
-- FUNCIONES Y TRIGGERS
-- ══════════════════════════════════════════════════════

-- Auto-crear wallet al registrar usuario
CREATE OR REPLACE FUNCTION create_wallet_on_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO wallets (user_id) VALUES (NEW.id);
  INSERT INTO kyc (user_id) VALUES (NEW.id);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_wallet_on_user
  AFTER INSERT ON users
  FOR EACH ROW EXECUTE FUNCTION create_wallet_on_user();

-- Auto-actualizar rating de rider
CREATE OR REPLACE FUNCTION update_rider_rating()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.rating IS NOT NULL THEN
    UPDATE riders SET rating = (
      SELECT ROUND(AVG(rating)::numeric, 2)
      FROM deliveries WHERE rider_id = NEW.rider_id AND rating IS NOT NULL
    ) WHERE id = NEW.rider_id;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_rider_rating
  AFTER INSERT OR UPDATE ON deliveries
  FOR EACH ROW EXECUTE FUNCTION update_rider_rating();

-- Auto-subir tier de rider
CREATE OR REPLACE FUNCTION update_rider_tier()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE riders SET tier = CASE
    WHEN NEW.deliveries >= 151 THEN 'gold'
    WHEN NEW.deliveries >= 51  THEN 'silver'
    ELSE 'bronze'
  END WHERE id = NEW.id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_rider_tier
  AFTER UPDATE OF deliveries ON riders
  FOR EACH ROW EXECUTE FUNCTION update_rider_tier();

-- Auto-actualizar rating de productos
CREATE OR REPLACE FUNCTION update_product_rating()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE products SET
    rating = (SELECT ROUND(AVG(rating)::numeric, 2) FROM reviews WHERE product_id = NEW.product_id),
    review_count = (SELECT COUNT(*) FROM reviews WHERE product_id = NEW.product_id)
  WHERE id = NEW.product_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_product_rating
  AFTER INSERT ON reviews
  FOR EACH ROW EXECUTE FUNCTION update_product_rating();

-- updated_at automático
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_users_updated BEFORE UPDATE ON users
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_wallets_updated BEFORE UPDATE ON wallets
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_orders_updated BEFORE UPDATE ON orders
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ══════════════════════════════════════════════════════
-- ROW LEVEL SECURITY (Supabase)
-- ══════════════════════════════════════════════════════
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE wallets ENABLE ROW LEVEL SECURITY;
ALTER TABLE transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

-- Usuarios solo ven sus propios datos
CREATE POLICY "users_own" ON users FOR ALL USING (auth.uid() = id);
CREATE POLICY "wallets_own" ON wallets FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "txns_own" ON transactions FOR SELECT USING (auth.uid() = user_id OR auth.uid() = recipient_id);
CREATE POLICY "orders_own" ON orders FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "notifs_own" ON notifications FOR ALL USING (auth.uid() = user_id);

-- ══════════════════════════════════════════════════════
-- DATOS INICIALES
-- ══════════════════════════════════════════════════════

-- Tasas de cambio iniciales
INSERT INTO exchange_rates (from_curr, to_curr, rate) VALUES
  ('EUR', 'XAF', 655.957),
  ('EUR', 'XOF', 655.957),
  ('EUR', 'USD', 1.0800),
  ('USD', 'XAF', 607.360),
  ('USD', 'XOF', 607.360),
  ('USD', 'EUR', 0.9260);

-- Usuario admin
INSERT INTO users (email, full_name, role, country, is_verified)
  VALUES ('admin@innovaafric.com', 'InnovaAFRIC Admin', 'admin', 'ES', TRUE);

COMMENT ON TABLE users IS 'Todos los tipos de usuario del ecosistema InnovaAFRIC';
COMMENT ON TABLE transactions IS 'Historial completo de todas las transacciones financieras';
COMMENT ON TABLE riders IS 'Riders con sistema de niveles Bronze/Silver/Gold';
COMMENT ON TABLE circulares IS 'Red de Circulares Autorizadas por territorio';
