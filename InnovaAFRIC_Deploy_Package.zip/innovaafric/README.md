# InnovaAFRIC · Guía de despliegue completo
**De cero a producción en 6 pasos**

---

## Estructura del proyecto

```
innovaafric/
├── schema.sql                  ← Base de datos PostgreSQL/Supabase
├── api/
│   ├── index.js                ← API REST v2 (Node.js + Supabase)
│   ├── package.json
│   ├── .env.example            ← Variables de entorno (copiar a .env)
│   ├── railway.toml            ← Config deploy Railway
│   └── Dockerfile
├── frontend/
│   ├── INNOVAAFRIC_Website_v2.html   ← Landing page
│   ├── INNOVAAFRIC_App_v4.html       ← App móvil (57+ pantallas)
│   ├── innovaafric-sdk.js      ← SDK de integración frontend ↔ API
│   ├── analytics.js            ← Eventos PostHog/Mixpanel
│   └── vercel.json             ← Config deploy Vercel
└── mobile/
    ├── capacitor.config.json   ← Config Capacitor (iOS/Android)
    └── package.json
```

---

## PASO 1 — Base de datos (Supabase) 🗄️

**Tiempo: 15 minutos**

1. Crear cuenta en [supabase.com](https://supabase.com)
2. Nuevo proyecto: `innovaafric-prod` | Región: `eu-west-1` (Frankfurt)
3. En SQL Editor, ejecutar:
   ```sql
   -- Pegar el contenido completo de schema.sql
   ```
4. Ir a Settings → API y copiar:
   - `Project URL` → `SUPABASE_URL`
   - `anon public key` → `SUPABASE_ANON_KEY`
   - `service_role key` → `SUPABASE_SERVICE_ROLE_KEY` ⚠️ Nunca al frontend

---

## PASO 2 — API en Railway 🚂

**Tiempo: 20 minutos | Coste: ~$5/mes**

```bash
# 1. Instalar Railway CLI
npm install -g @railway/cli

# 2. Login y crear proyecto
railway login
cd api/
railway init

# 3. Configurar variables de entorno
railway variables set SUPABASE_URL=https://xxxx.supabase.co
railway variables set SUPABASE_SERVICE_ROLE_KEY=eyJhbGc...
railway variables set JWT_SECRET=$(node -e "console.log(require('crypto').randomBytes(64).toString('hex'))")
railway variables set NODE_ENV=production
railway variables set ALLOWED_ORIGINS=https://innovaafric.com,https://app.innovaafric.com

# 4. Deploy
railway up

# 5. Obtener URL del API
railway domain
# → https://innovaafric-api.up.railway.app
```

**Alternativa: Render.com** (también gratuito en tier starter)
```bash
# render.yaml ya incluido
# Conectar repo en render.com → New Web Service
```

---

## PASO 3 — Landing page y App en Vercel 🌐

**Tiempo: 10 minutos | Coste: Gratis**

```bash
# 1. Instalar Vercel CLI
npm install -g vercel

# 2. Desde la carpeta frontend/
cd frontend/
vercel

# 3. En el dashboard de Vercel, añadir variables:
#    VITE_API_URL = https://innovaafric-api.up.railway.app

# 4. Dominio personalizado
vercel domains add innovaafric.com
vercel domains add app.innovaafric.com

# Rutas automáticas:
# innovaafric.com       → INNOVAAFRIC_Website_v2.html (landing)
# innovaafric.com/app   → INNOVAAFRIC_App_v4.html (app)
```

---

## PASO 4 — Conectar el SDK al frontend 🔗

En `INNOVAAFRIC_App_v4.html`, añadir antes de `</body>`:

```html
<!-- SDK de integración -->
<script type="module">
  import api from './innovaafric-sdk.js';

  // Reemplazar datos hardcodeados por llamadas reales
  window.addEventListener('load', async function() {

    // Si hay sesión activa, cargar datos reales
    if (api.auth.isLoggedIn()) {
      try {
        const [wallet, user] = await Promise.all([
          api.wallet.get(),
          api.auth.me()
        ]);

        // Actualizar balance en Home
        const balanceEl = document.getElementById('balance-eur');
        if (balanceEl) balanceEl.textContent = '€ ' + Number(wallet.eur).toFixed(2);

        // Actualizar nombre de usuario
        const nameEl = document.querySelector('[data-user-name]');
        if (nameEl) nameEl.textContent = user.user.full_name.split(' ')[0];

      } catch (err) {
        console.error('Error cargando datos:', err);
      }
    }
  });

  // Exponer api globalmente para los onclick del HTML
  window.api = api;
  window.Analytics = (await import('./analytics.js')).default;
</script>
```

---

## PASO 5 — App nativa con Capacitor 📱

**Tiempo: 2 horas | Requiere: Xcode (iOS) o Android Studio**

```bash
# 1. Instalar dependencias
cd mobile/
npm install

# 2. Instalar CLI de Capacitor
npm install -g @capacitor/cli

# 3. Inicializar (apunta al HTML)
cap init InnovaAFRIC com.innovaafric.app --web-dir ..

# 4. Copiar los HTML al directorio web
cp ../frontend/INNOVAAFRIC_App_v4.html ./index.html
cp ../frontend/innovaafric-sdk.js ./
cp ../frontend/analytics.js ./

# 5. Añadir plataformas
cap add ios
cap add android

# 6. Sincronizar
cap sync

# 7. Abrir en IDE nativo
cap open ios       # → Xcode
cap open android   # → Android Studio

# 8. Para publicar en App Store / Play Store:
# iOS: Product → Archive → Distribute App en Xcode
# Android: Build → Generate Signed Bundle en Android Studio
```

**Capacitor plugins activados:**
- Camera (escanear QR, foto de entrega)
- Geolocation (tracking riders)
- Push Notifications (via FCM)
- Biometric Auth (PIN + Face ID / huella)
- Local Notifications
- Share (compartir comprobantes)
- Network (detectar conexión para modo offline)

---

## PASO 6 — Analytics y monitoreo 📊

```bash
# PostHog (analytics)
# 1. Crear cuenta en posthog.com → Get API key
# 2. Añadir al .env:
POSTHOG_API_KEY=phc_xxxxxxxxxxxx

# 3. En el HTML, añadir el snippet de analytics.js
# 4. Los eventos ya están implementados en el SDK

# Sentry (errores)
npm install @sentry/browser
# Añadir DSN en .env: SENTRY_DSN=https://xxx@sentry.io/xxx
```

---

## Checklist de lanzamiento ✅

### Infraestructura
- [ ] Supabase proyecto creado y schema ejecutado
- [ ] API deployed en Railway con URL pública
- [ ] Frontend deployed en Vercel con dominio
- [ ] Variables de entorno configuradas en todos los servicios
- [ ] SSL/HTTPS activo en todos los dominios

### Funcional
- [ ] Register/Login funciona end-to-end
- [ ] Wallet se carga con datos reales de Supabase
- [ ] Envío de dinero crea transacción en DB
- [ ] Carrito de compra y pedido funcionan
- [ ] Notificaciones llegan al teléfono (FCM)

### Calidad
- [ ] Analytics registrando eventos en PostHog
- [ ] Sentry capturando errores
- [ ] Test de carga: 100 usuarios concurrentes OK
- [ ] App funciona con 3G lento (throttle en DevTools)
- [ ] App nativa aprobada en App Store y Play Store

### Negocio
- [ ] Al menos 1 Circular operativa en Malabo
- [ ] 5+ riders activos en ciudad piloto
- [ ] MTN/Orange Money en modo producción (no sandbox)
- [ ] Soporte al cliente configurado (WhatsApp Business + Zendesk)

---

## URLs finales

| Servicio | URL | Estado |
|----------|-----|--------|
| Landing  | https://innovaafric.com | → Vercel |
| App web  | https://innovaafric.com/app | → Vercel |
| API      | https://api.innovaafric.com | → Railway |
| Docs API | https://api.innovaafric.com/docs | → Swagger |
| Admin    | https://admin.innovaafric.com | → Supabase Studio |
| Analytics | https://eu.posthog.com | → PostHog |

---

## Coste mensual estimado

| Servicio | Plan | Coste |
|----------|------|-------|
| Supabase | Free (hasta 500MB) → Pro $25/mes | $0–25 |
| Railway  | Starter $5/mes | $5 |
| Vercel   | Free | $0 |
| PostHog  | Free (1M eventos/mes) | $0 |
| Dominio  | .com/año | $12/año |
| **Total** | | **~$30–42/mes** |

Con 100+ usuarios activos, el coste de Supabase Pro ($25) se amortiza completamente.

---

*InnovaAFRIC · We Simplify Life · Asia → España → África*
