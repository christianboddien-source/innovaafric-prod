// ══════════════════════════════════════════════════════
// InnovaAFRIC · API v2 — Backend productivo
// Node.js + Express + Supabase/PostgreSQL
// ══════════════════════════════════════════════════════
// Inicio: node index.js  |  Dev: nodemon index.js
// Deploy: railway up     |  Test: npm test

import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { createClient } from '@supabase/supabase-js';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';

const app = express();
const PORT = process.env.PORT || 3000;

// ── SUPABASE CLIENT ────────────────────────────────────
export const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY // service role para el backend
);

// ── MIDDLEWARE ─────────────────────────────────────────
app.use(helmet());
app.use(cors({ origin: process.env.ALLOWED_ORIGINS?.split(',') || '*' }));
app.use(express.json({ limit: '10mb' }));

// Rate limiting general
app.use(rateLimit({
  windowMs: 15 * 60 * 1000, // 15 min
  max: 200,
  standardHeaders: true,
  message: { error: 'Demasiadas peticiones. Intenta en 15 minutos.' }
}));

// Rate limiting estricto para auth
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  message: { error: 'Demasiados intentos de login. Espera 15 minutos.' }
});

// ── MIDDLEWARE AUTH ────────────────────────────────────
export const requireAuth = async (req, res, next) => {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) return res.status(401).json({ error: 'Token requerido' });
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    const { data: user } = await supabase
      .from('users').select('*').eq('id', payload.userId).single();
    if (!user || !user.is_active) return res.status(401).json({ error: 'Usuario no válido' });
    req.user = user;
    next();
  } catch {
    return res.status(401).json({ error: 'Token inválido o expirado' });
  }
};

const requireRole = (...roles) => (req, res, next) => {
  if (!roles.includes(req.user?.role))
    return res.status(403).json({ error: 'Sin permisos para esta acción' });
  next();
};

// ── UTILIDADES ─────────────────────────────────────────
const RATES = {
  'EUR-XAF': 655.957, 'EUR-XOF': 655.957, 'EUR-USD': 1.08,
  'USD-XAF': 607.36, 'USD-XOF': 607.36, 'USD-EUR': 0.926
};

function getRate(from, to) {
  if (from === to) return 1;
  return RATES[`${from}-${to}`] || (1 / (RATES[`${to}-${from}`] || 1));
}

function calcFee(amount, type) {
  const rates = { send: 0.02, cashout: 0.015, qr: 0.015, shop: 0.15, bigshop: 0.08 };
  return amount * (rates[type] || 0.02);
}

// ══════════════════════════════════════════════════════
// RUTAS — AUTH
// ══════════════════════════════════════════════════════
app.post('/auth/register', authLimiter, async (req, res) => {
  const { email, password, full_name, role, country, phone } = req.body;
  if (!email || !password || !full_name || !role)
    return res.status(400).json({ error: 'Faltan campos requeridos' });

  // Crear en Supabase Auth
  const { data: authData, error: authErr } = await supabase.auth.admin.createUser({
    email, password, email_confirm: true
  });
  if (authErr) return res.status(400).json({ error: authErr.message });

  // Crear perfil en tabla users
  const { data: user, error } = await supabase.from('users').insert({
    id: authData.user.id, email, full_name, role, country, phone
  }).select().single();

  if (error) return res.status(400).json({ error: error.message });

  const token = jwt.sign({ userId: user.id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '7d' });
  res.status(201).json({ user: { id: user.id, email, full_name, role }, token });
});

app.post('/auth/login', authLimiter, async (req, res) => {
  const { email, password } = req.body;
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) return res.status(401).json({ error: 'Credenciales incorrectas' });

  const { data: user } = await supabase.from('users').select('*').eq('id', data.user.id).single();
  if (!user?.is_active) return res.status(401).json({ error: 'Cuenta suspendida' });

  const token = jwt.sign({ userId: user.id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '7d' });
  res.json({ user: { id: user.id, email: user.email, full_name: user.full_name, role: user.role, lang: user.lang }, token });
});

app.get('/auth/me', requireAuth, (req, res) => res.json({ user: req.user }));

app.post('/auth/refresh', requireAuth, (req, res) => {
  const token = jwt.sign({ userId: req.user.id, role: req.user.role }, process.env.JWT_SECRET, { expiresIn: '7d' });
  res.json({ token });
});

// ══════════════════════════════════════════════════════
// RUTAS — WALLET (XenderMoney)
// ══════════════════════════════════════════════════════
app.get('/wallet', requireAuth, async (req, res) => {
  const { data } = await supabase.from('wallets').select('*').eq('user_id', req.user.id).single();
  res.json(data);
});

app.get('/wallet/history', requireAuth, async (req, res) => {
  const { type, status, limit = 20, page = 1 } = req.query;
  let query = supabase.from('transactions')
    .select('*, recipient:recipient_id(full_name,phone)', { count: 'exact' })
    .or(`user_id.eq.${req.user.id},recipient_id.eq.${req.user.id}`)
    .order('created_at', { ascending: false })
    .range((page - 1) * limit, page * limit - 1);

  if (type) query = query.eq('type', type);
  if (status) query = query.eq('status', status);
  const { data, count } = await query;
  res.json({ data, total: count, page: +page, limit: +limit });
});

app.get('/wallet/rates', async (req, res) => {
  const { data } = await supabase.from('exchange_rates')
    .select('*').eq('date', new Date().toISOString().split('T')[0]);
  res.json(data?.length ? data : Object.entries(RATES).map(([k, v]) => ({
    from_curr: k.split('-')[0], to_curr: k.split('-')[1], rate: v
  })));
});

app.post('/wallet/send', requireAuth, async (req, res) => {
  const { amount, currency, currency_recv = 'XAF', recipient_phone, recipient_id, description } = req.body;
  if (!amount || amount <= 0) return res.status(400).json({ error: 'Importe inválido' });

  const fee = calcFee(amount, 'send');
  const total = amount + fee;
  const rate = getRate(currency, currency_recv);
  const amount_recv = (amount - fee) * rate;

  // Verificar saldo
  const { data: wallet } = await supabase.from('wallets').select(currency.toLowerCase()).eq('user_id', req.user.id).single();
  if (!wallet || wallet[currency.toLowerCase()] < total)
    return res.status(400).json({ error: 'Saldo insuficiente' });

  // KYC check
  const { data: kyc } = await supabase.from('kyc').select('level').eq('user_id', req.user.id).single();
  const limits = [200, 2000, Infinity];
  if (amount > limits[kyc?.level ?? 0])
    return res.status(400).json({ error: `Límite KYC nivel ${kyc?.level ?? 0}: €${limits[kyc?.level ?? 0]}` });

  // Crear transacción
  const { data: txn, error } = await supabase.from('transactions').insert({
    user_id: req.user.id, type: 'send', amount, currency, amount_recv,
    currency_recv, fee, rate, status: 'processing', recipient_id, recipient_phone, description
  }).select().single();

  if (error) return res.status(500).json({ error: error.message });

  // Actualizar wallets (usar RPC para atomicidad)
  await supabase.rpc('process_transfer', {
    p_txn_id: txn.id, p_sender_id: req.user.id, p_total_debit: total,
    p_currency: currency.toLowerCase(), p_recipient_id: recipient_id,
    p_amount_recv: amount_recv, p_currency_recv: currency_recv.toLowerCase()
  });

  // Puntos: 1 punto por euro enviado
  await supabase.from('points_log').insert({
    user_id: req.user.id, amount: Math.floor(amount), type: 'earn', source: 'send', ref_id: txn.id
  });

  res.status(201).json({ transaction: txn, message: 'Transferencia iniciada' });
});

app.post('/wallet/p2p', requireAuth, async (req, res) => {
  const { amount, currency = 'XAF', recipient_id } = req.body;
  if (!recipient_id) return res.status(400).json({ error: 'Destinatario requerido' });

  const { data: wallet } = await supabase.from('wallets').select(currency.toLowerCase()).eq('user_id', req.user.id).single();
  if (!wallet || wallet[currency.toLowerCase()] < amount)
    return res.status(400).json({ error: 'Saldo insuficiente' });

  const { data: txn } = await supabase.from('transactions').insert({
    user_id: req.user.id, type: 'p2p', amount, currency, amount_recv: amount,
    currency_recv: currency, fee: 0, rate: 1, status: 'completed', recipient_id
  }).select().single();

  await supabase.rpc('process_p2p', {
    p_sender_id: req.user.id, p_recipient_id: recipient_id,
    p_amount: amount, p_currency: currency.toLowerCase()
  });

  res.status(201).json({ transaction: txn, message: 'P2P completado — sin comisión' });
});

app.post('/wallet/cashout', requireAuth, async (req, res) => {
  const { amount, currency = 'EUR', method } = req.body;
  const fee = calcFee(amount, 'cashout');

  const { data: txn } = await supabase.from('transactions').insert({
    user_id: req.user.id, type: 'cashout', amount, currency, fee,
    status: 'processing', description: `Reintegro via ${method}`
  }).select().single();

  res.status(201).json({ transaction: txn, message: `Reintegro solicitado (${method}). Tiempo: ${method === 'circular' ? '15 min' : '2-24h'}` });
});

app.post('/wallet/qr-pay', requireAuth, async (req, res) => {
  const { merchant_qr, amount, currency = 'XAF' } = req.body;

  const { data: merchant } = await supabase.from('merchants').select('*, user:user_id(full_name)').eq('qr_code', merchant_qr).single();
  if (!merchant) return res.status(404).json({ error: 'Comercio no encontrado' });

  const fee = calcFee(amount, 'qr');
  const { data: wallet } = await supabase.from('wallets').select(currency.toLowerCase()).eq('user_id', req.user.id).single();
  if (!wallet || wallet[currency.toLowerCase()] < amount)
    return res.status(400).json({ error: 'Saldo insuficiente' });

  const { data: payment } = await supabase.from('qr_payments').insert({
    merchant_id: merchant.id, user_id: req.user.id, amount, currency
  }).select().single();

  await supabase.from('transactions').insert({
    user_id: req.user.id, type: 'qr_pay', amount, currency, fee,
    status: 'completed', description: `Pago QR: ${merchant.name}`, metadata: { merchant_id: merchant.id }
  });

  res.json({ payment, merchant: { name: merchant.name }, message: '¡Pago completado!' });
});

// Envíos recurrentes
app.get('/wallet/recurring', requireAuth, async (req, res) => {
  const { data } = await supabase.from('recurring_transfers')
    .select('*, recipient:recipient_id(full_name,phone)').eq('user_id', req.user.id).eq('is_active', true);
  res.json(data);
});

app.post('/wallet/recurring', requireAuth, async (req, res) => {
  const { recipient_id, recipient_phone, amount, currency, currency_recv, frequency, start_date } = req.body;
  const { data } = await supabase.from('recurring_transfers').insert({
    user_id: req.user.id, recipient_id, recipient_phone, amount, currency, currency_recv, frequency,
    next_run: start_date || new Date().toISOString().split('T')[0]
  }).select().single();
  res.status(201).json(data);
});

// ══════════════════════════════════════════════════════
// RUTAS — XENDERSHOP
// ══════════════════════════════════════════════════════
app.get('/shop/products', async (req, res) => {
  const { category, search, flash, page = 1, limit = 20 } = req.query;
  let query = supabase.from('products').select('*', { count: 'exact' })
    .eq('is_active', true).order('created_at', { ascending: false })
    .range((page - 1) * limit, page * limit - 1);

  if (category) query = query.eq('category', category);
  if (flash === 'true') query = query.eq('is_flash_sale', true).gt('flash_ends_at', new Date().toISOString());
  if (search) query = query.ilike('name', `%${search}%`);
  const { data, count } = await query;
  res.json({ data, total: count });
});

app.get('/shop/products/:id', async (req, res) => {
  const { data: product } = await supabase.from('products').select('*, supplier:supplier_id(*, user:user_id(full_name, country))').eq('id', req.params.id).single();
  const { data: reviews } = await supabase.from('reviews').select('*, user:user_id(full_name)').eq('product_id', req.params.id).order('created_at', { ascending: false }).limit(10);
  res.json({ product, reviews });
});

app.post('/shop/orders', requireAuth, async (req, res) => {
  const { items, currency, delivery_address } = req.body;
  if (!items?.length) return res.status(400).json({ error: 'Sin productos' });

  let total_eur = 0;
  const orderItems = [];

  for (const item of items) {
    const { data: prod } = await supabase.from('products').select('*').eq('id', item.product_id).single();
    if (!prod || prod.stock < item.qty) return res.status(400).json({ error: `Sin stock: ${prod?.name}` });
    total_eur += prod.price_eur * item.qty;
    orderItems.push({ product_id: item.product_id, name: prod.name, qty: item.qty, price: prod.price_eur, currency: 'EUR' });
  }

  const { data: order } = await supabase.from('orders').insert({
    user_id: req.user.id, type: 'shop', total_eur, currency_paid: currency || 'EUR',
    delivery_address, tracking_code: 'ORD-' + Date.now()
  }).select().single();

  await supabase.from('order_items').insert(orderItems.map(i => ({ ...i, order_id: order.id })));
  await supabase.from('shipment_tracking').insert({ order_id: order.id, status: 'ordered', description: 'Pedido confirmado' });

  // Puntos: 2 puntos por euro en Shop
  await supabase.from('points_log').insert({ user_id: req.user.id, amount: Math.floor(total_eur * 2), type: 'earn', source: 'shop', ref_id: order.id });

  res.status(201).json({ order, message: 'Pedido confirmado · Envío en 3–5 días' });
});

app.get('/shop/orders/:id/tracking', requireAuth, async (req, res) => {
  const { data } = await supabase.from('shipment_tracking').select('*').eq('order_id', req.params.id).order('timestamp');
  res.json(data);
});

app.post('/shop/products/:id/review', requireAuth, async (req, res) => {
  const { rating, comment, order_id } = req.body;
  const { data, error } = await supabase.from('reviews').insert({
    product_id: req.params.id, user_id: req.user.id, order_id, rating, comment
  }).select().single();
  if (error) return res.status(400).json({ error: error.message });
  res.status(201).json(data);
});

// ══════════════════════════════════════════════════════
// RUTAS — XENDERBIGSHOP
// ══════════════════════════════════════════════════════
app.get('/bigshop/items', async (req, res) => {
  const { category, fresh } = req.query;
  let query = supabase.from('grocery_items').select('*').eq('is_active', true).gt('stock', 0);
  if (category) query = query.eq('category', category);
  if (fresh === 'true') query = query.eq('is_fresh', true);
  const { data } = await query;
  res.json(data);
});

app.post('/bigshop/orders', requireAuth, async (req, res) => {
  const { items, address, date, time_slot } = req.body;
  const total_xaf = items.reduce((s, i) => s + (i.price_xaf * i.qty), 0);
  const { data: order } = await supabase.from('scheduled_orders').insert({
    user_id: req.user.id, items, total_xaf, address, scheduled_date: date, time_slot
  }).select().single();
  res.status(201).json({ order, message: `Pedido programado para ${date} en franja ${time_slot}` });
});

// ══════════════════════════════════════════════════════
// RUTAS — RIDERS
// ══════════════════════════════════════════════════════
app.get('/riders/me', requireAuth, requireRole('rider'), async (req, res) => {
  const { data } = await supabase.from('riders').select('*').eq('user_id', req.user.id).single();
  res.json(data);
});

app.get('/riders/me/deliveries', requireAuth, requireRole('rider'), async (req, res) => {
  const { data: rider } = await supabase.from('riders').select('id').eq('user_id', req.user.id).single();
  const { data } = await supabase.from('deliveries').select('*, order:order_id(*, user:user_id(full_name,phone))')
    .eq('rider_id', rider.id).order('assigned_at', { ascending: false }).limit(20);
  res.json(data);
});

app.put('/riders/deliveries/:id/status', requireAuth, requireRole('rider'), async (req, res) => {
  const { status, photo_proof, signature_url, rating } = req.body;
  const update = { status };
  if (status === 'delivered') { update.delivered_at = new Date().toISOString(); update.photo_proof = photo_proof; update.signature_url = signature_url; }

  const { data } = await supabase.from('deliveries').update(update).eq('id', req.params.id).select().single();

  if (status === 'delivered') {
    // Sumar entrega al rider
    const { data: rider } = await supabase.from('riders').select('id,deliveries').eq('user_id', req.user.id).single();
    await supabase.from('riders').update({ deliveries: rider.deliveries + 1 }).eq('id', rider.id);
    await supabase.from('orders').update({ status: 'delivered', delivered_at: new Date().toISOString() }).eq('id', data.order_id);
  }
  res.json(data);
});

app.get('/riders/me/earnings', requireAuth, requireRole('rider'), async (req, res) => {
  const { data: rider } = await supabase.from('riders').select('*, bonus:rider_bonuses(*)').eq('user_id', req.user.id).single();
  const { data: today } = await supabase.from('deliveries')
    .select('fee,tip').eq('rider_id', rider.id).eq('status', 'delivered')
    .gte('delivered_at', new Date().toISOString().split('T')[0]);
  const todayEarnings = (today || []).reduce((s, d) => s + Number(d.fee) + Number(d.tip), 0);
  res.json({ rider, today_earnings: todayEarnings });
});

// ══════════════════════════════════════════════════════
// RUTAS — CIRCULARES
// ══════════════════════════════════════════════════════
app.get('/circular/me', requireAuth, requireRole('circular'), async (req, res) => {
  const { data } = await supabase.from('circulares').select('*').eq('user_id', req.user.id).single();
  res.json(data);
});

app.get('/circular/me/riders', requireAuth, requireRole('circular'), async (req, res) => {
  const { data: circular } = await supabase.from('circulares').select('id').eq('user_id', req.user.id).single();
  const { data } = await supabase.from('riders').select('*, user:user_id(full_name,phone,email)').eq('circular_id', circular.id);
  res.json(data);
});

app.get('/circular/me/merchants', requireAuth, requireRole('circular'), async (req, res) => {
  const { data: circular } = await supabase.from('circulares').select('id').eq('user_id', req.user.id).single();
  const { data } = await supabase.from('merchants').select('*').eq('circular_id', circular.id);
  res.json(data);
});

app.get('/circular/me/commissions', requireAuth, requireRole('circular'), async (req, res) => {
  const { data: circular } = await supabase.from('circulares').select('id').eq('user_id', req.user.id).single();
  const { month } = req.query;
  let q = supabase.from('circular_commissions').select('*').eq('circular_id', circular.id);
  if (month) q = q.eq('month', month);
  const { data } = await q.order('created_at', { ascending: false });
  const total = data?.reduce((s, c) => s + Number(c.amount), 0) || 0;
  res.json({ commissions: data, total_eur: total });
});

// ══════════════════════════════════════════════════════
// RUTAS — NOTIFICACIONES
// ══════════════════════════════════════════════════════
app.get('/notifications', requireAuth, async (req, res) => {
  const { data, count } = await supabase.from('notifications')
    .select('*', { count: 'exact' }).eq('user_id', req.user.id)
    .order('created_at', { ascending: false }).limit(30);
  const unread = await supabase.from('notifications').select('id', { count: 'exact' }).eq('user_id', req.user.id).eq('is_read', false);
  res.json({ data, total: count, unread: unread.count });
});

app.put('/notifications/read-all', requireAuth, async (req, res) => {
  await supabase.from('notifications').update({ is_read: true }).eq('user_id', req.user.id).eq('is_read', false);
  res.json({ message: 'Todas leídas' });
});

// ══════════════════════════════════════════════════════
// RUTAS — PUNTOS Y REFERIDOS
// ══════════════════════════════════════════════════════
app.get('/points', requireAuth, async (req, res) => {
  const { data: wallet } = await supabase.from('wallets').select('points').eq('user_id', req.user.id).single();
  const { data: log } = await supabase.from('points_log').select('*').eq('user_id', req.user.id).order('created_at', { ascending: false }).limit(20);
  res.json({ points: wallet?.points || 0, log });
});

app.post('/points/redeem', requireAuth, async (req, res) => {
  const { points, reward } = req.body;
  const { data: wallet } = await supabase.from('wallets').select('points').eq('user_id', req.user.id).single();
  if (wallet.points < points) return res.status(400).json({ error: 'Puntos insuficientes' });
  await supabase.from('wallets').update({ points: wallet.points - points }).eq('user_id', req.user.id);
  await supabase.from('points_log').insert({ user_id: req.user.id, amount: -points, type: 'redeem', source: 'send' });
  res.json({ message: `¡${reward} canjeado!`, remaining: wallet.points - points });
});

app.get('/referrals', requireAuth, async (req, res) => {
  const { data } = await supabase.from('referrals').select('*, referred:referred_id(full_name,created_at)').eq('referrer_id', req.user.id);
  const earned = (data || []).filter(r => r.paid).reduce((s, r) => s + Number(r.reward_eur), 0);
  res.json({ referrals: data, total_earned: earned, code: req.user.referral_code });
});

// ══════════════════════════════════════════════════════
// RUTAS — ADMIN (Dashboard)
// ══════════════════════════════════════════════════════
app.get('/admin/stats', requireAuth, requireRole('admin'), async (req, res) => {
  const [users, txns, orders, riders, circulares, merchants] = await Promise.all([
    supabase.from('users').select('id', { count: 'exact' }).eq('is_active', true),
    supabase.from('transactions').select('amount', { count: 'exact' }).eq('status', 'completed'),
    supabase.from('orders').select('id', { count: 'exact' }),
    supabase.from('riders').select('id', { count: 'exact' }).eq('is_online', true),
    supabase.from('circulares').select('id', { count: 'exact' }).eq('status', 'active'),
    supabase.from('merchants').select('id', { count: 'exact' }).eq('is_active', true)
  ]);
  const revenue = txns.data?.reduce((s, t) => s + Number(t.amount) * 0.02, 0) || 0;
  res.json({
    users: users.count, transactions: txns.count, orders: orders.count,
    riders_online: riders.count, circulares: circulares.count, merchants: merchants.count,
    revenue_eur: Math.round(revenue)
  });
});

app.get('/admin/users', requireAuth, requireRole('admin'), async (req, res) => {
  const { role, country, page = 1, limit = 50 } = req.query;
  let q = supabase.from('users').select('*, kyc(*), wallet:wallets(*)', { count: 'exact' })
    .order('created_at', { ascending: false }).range((page - 1) * limit, page * limit - 1);
  if (role) q = q.eq('role', role);
  if (country) q = q.eq('country', country);
  const { data, count } = await q;
  res.json({ data, total: count });
});

// ══════════════════════════════════════════════════════
// RUTAS — MISC
// ══════════════════════════════════════════════════════
app.get('/health', (req, res) => res.json({ status: 'ok', version: '2.0.0', env: process.env.NODE_ENV }));
app.get('/', (req, res) => res.json({ api: 'InnovaAFRIC API', version: '2.0.0', docs: '/docs' }));
app.use((req, res) => res.status(404).json({ error: 'Endpoint no encontrado' }));
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Error interno del servidor' });
});

app.listen(PORT, () => console.log(`InnovaAFRIC API v2 corriendo en :${PORT}`));
export default app;
