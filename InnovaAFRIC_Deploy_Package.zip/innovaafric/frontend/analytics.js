// ══════════════════════════════════════════════════════
// InnovaAFRIC · Analytics — PostHog + eventos de negocio
// Añadir en el <head> del HTML o importar en el proyecto
// ══════════════════════════════════════════════════════

// ── INICIALIZACIÓN PostHog ─────────────────────────────
(function() {
  const POSTHOG_KEY = window.ENV_POSTHOG_KEY || '__REPLACE_WITH_KEY__';
  const POSTHOG_HOST = 'https://eu.posthog.com'; // Servidor EU para GDPR

  !function(t,e){var o,n,p,r;e.__SV||(window.posthog=e,e._i=[],e.init=function(i,s,a){function g(t,e){var o=e.split(".");2==o.length&&(t=t[o[0]],e=o[1]),t[e]=function(){t.push([e].concat(Array.prototype.slice.call(arguments,0)))}}(p=t.createElement("script")).type="text/javascript",p.async=!0,p.src=s.api_host+"/static/array.js",(r=t.getElementsByTagName("script")[0]).parentNode.insertBefore(p,r);var u=e;for(void 0!==a?u=e[a]=[]:a="posthog",u.people=u.people||[],u.toString=function(t){var e="posthog";return"posthog"!==a&&(e+="."+a),t||(e+=" (stub)"),e},u.people.toString=function(){return u.toString(1)+" (stub)"},o="capture identify alias people.set people.set_once set_config register register_once unregister opt_out_capturing has_opted_out_capturing opt_in_capturing reset isFeatureEnabled onFeatureFlags getFeatureFlag getFeatureFlagPayload reloadFeatureFlags group updateEarlyAccessFeatureEnrollment getEarlyAccessFeatures getActiveMatchingSurveys getSurveys".split(" "),n=0;n<o.length;n++)g(u,o[n]);e._i.push([i,s,a])},e.__SV=1)}(document,window.posthog||[]);

  posthog.init(POSTHOG_KEY, {
    api_host: POSTHOG_HOST,
    capture_pageview: true,
    capture_pageleave: true,
    autocapture: false, // Manual para controlar qué capturamos
    disable_session_recording: false,
    persistence: 'localStorage',
    loaded: function(ph) {
      // No rastrear en desarrollo
      if (window.location.hostname === 'localhost') ph.opt_out_capturing();
    }
  });
})();

// ══════════════════════════════════════════════════════
// EVENTOS DE NEGOCIO — InnovaAFRIC Analytics SDK
// Todas las acciones importantes del ecosistema
// ══════════════════════════════════════════════════════
const Analytics = {

  // ── IDENTIFICAR USUARIO ───────────────────────────────
  identify(userId, traits = {}) {
    if (typeof posthog !== 'undefined') {
      posthog.identify(userId, {
        email: traits.email,
        name: traits.full_name,
        role: traits.role,
        country: traits.country,
        lang: traits.lang,
        created_at: traits.created_at
      });
    }
  },

  reset() {
    if (typeof posthog !== 'undefined') posthog.reset();
  },

  // ── HELPER INTERNO ────────────────────────────────────
  track(event, props = {}) {
    if (typeof posthog !== 'undefined') {
      posthog.capture(event, {
        ...props,
        timestamp: new Date().toISOString(),
        platform: /iPhone|Android/.test(navigator.userAgent) ? 'mobile_web' : 'web'
      });
    }
    if (window.gtag) window.gtag('event', event, props);
    console.debug('[Analytics]', event, props);
  },

  // ══════════════════════════════════════════════════════
  // XENDERMONEY — Eventos financieros
  // ══════════════════════════════════════════════════════
  money: {
    sendInitiated(amount, currency, currencyRecv) {
      Analytics.track('money_send_initiated', { amount, currency, currency_recv: currencyRecv });
    },
    sendCompleted(txnId, amount, currency, feeAmount) {
      Analytics.track('money_send_completed', { txn_id: txnId, amount, currency, fee: feeAmount, revenue: feeAmount });
    },
    sendFailed(reason) {
      Analytics.track('money_send_failed', { reason });
    },
    p2pCompleted(amount, currency) {
      Analytics.track('money_p2p_completed', { amount, currency });
    },
    cashoutRequested(amount, currency, method) {
      Analytics.track('money_cashout_requested', { amount, currency, method });
    },
    qrPayCompleted(amount, currency, merchantId) {
      Analytics.track('money_qr_pay_completed', { amount, currency, merchant_id: merchantId, revenue: amount * 0.015 });
    },
    converterUsed(amount, from, to) {
      Analytics.track('money_converter_used', { amount, from, to });
    },
    recurringCreated(frequency, amount, currency) {
      Analytics.track('money_recurring_created', { frequency, amount, currency });
    }
  },

  // ══════════════════════════════════════════════════════
  // XENDERSHOP — E-commerce
  // ══════════════════════════════════════════════════════
  shop: {
    productViewed(productId, name, category, price) {
      Analytics.track('shop_product_viewed', { product_id: productId, name, category, price });
    },
    addedToCart(productId, name, price) {
      Analytics.track('shop_added_to_cart', { product_id: productId, name, price });
    },
    checkoutStarted(total, currency, itemCount) {
      Analytics.track('shop_checkout_started', { total, currency, item_count: itemCount });
    },
    orderCompleted(orderId, total, currency) {
      Analytics.track('shop_order_completed', { order_id: orderId, total, currency, revenue: total * 0.15 });
    },
    flashSaleClicked(productId, discount) {
      Analytics.track('shop_flash_sale_clicked', { product_id: productId, discount_pct: discount });
    },
    reviewLeft(productId, rating) {
      Analytics.track('shop_review_left', { product_id: productId, rating });
    }
  },

  // ══════════════════════════════════════════════════════
  // XENDERBIGSHOP — Grocery
  // ══════════════════════════════════════════════════════
  bigshop: {
    orderPlaced(total, itemCount, timeSlot) {
      Analytics.track('bigshop_order_placed', { total_xaf: total, item_count: itemCount, time_slot: timeSlot, revenue: total * 0.08 / 655.957 });
    },
    scheduledOrderCreated(date, timeSlot) {
      Analytics.track('bigshop_scheduled_order', { date, time_slot: timeSlot });
    },
    subscriptionStarted(plan) {
      Analytics.track('bigshop_plus_subscribed', { plan, mrr: 4.99 });
    }
  },

  // ══════════════════════════════════════════════════════
  // REGISTRO Y ONBOARDING
  // ══════════════════════════════════════════════════════
  auth: {
    registrationStarted(role) {
      Analytics.track('auth_registration_started', { role });
    },
    registrationCompleted(userId, role, country) {
      Analytics.track('auth_registration_completed', { user_id: userId, role, country });
      Analytics.identify(userId, { role, country });
    },
    loginSucceeded(userId, method = 'email') {
      Analytics.track('auth_login_succeeded', { user_id: userId, method });
    },
    kycStarted(level) {
      Analytics.track('auth_kyc_started', { level });
    },
    kycCompleted(level) {
      Analytics.track('auth_kyc_completed', { level });
    },
    onboardingStepCompleted(step, total) {
      Analytics.track('auth_onboarding_step', { step, total, progress: step / total });
    }
  },

  // ══════════════════════════════════════════════════════
  // CIRCULARES Y RIDERS
  // ══════════════════════════════════════════════════════
  circular: {
    applicationSubmitted(territory, investmentTier) {
      Analytics.track('circular_application_submitted', { territory, investment_tier: investmentTier });
    },
    activated(circularId, territory) {
      Analytics.track('circular_activated', { circular_id: circularId, territory });
    }
  },
  rider: {
    applicationSubmitted(vehicleType, city) {
      Analytics.track('rider_application_submitted', { vehicle_type: vehicleType, city });
    },
    deliveryCompleted(deliveryId, fee, tier) {
      Analytics.track('rider_delivery_completed', { delivery_id: deliveryId, fee, tier });
    },
    tierUpgraded(oldTier, newTier) {
      Analytics.track('rider_tier_upgraded', { from: oldTier, to: newTier });
    }
  },

  // ══════════════════════════════════════════════════════
  // ENGAGEMENT
  // ══════════════════════════════════════════════════════
  engagement: {
    referralShared(channel) {
      Analytics.track('referral_shared', { channel });
    },
    referralConverted(referrerId) {
      Analytics.track('referral_converted', { referrer_id: referrerId, reward_eur: 5 });
    },
    pointsEarned(amount, source) {
      Analytics.track('points_earned', { amount, source });
    },
    pointsRedeemed(amount, reward) {
      Analytics.track('points_redeemed', { amount, reward });
    },
    npsSubmitted(score) {
      Analytics.track('nps_submitted', { score, category: score >= 9 ? 'promoter' : score >= 7 ? 'passive' : 'detractor' });
    },
    langChanged(from, to) {
      Analytics.track('lang_changed', { from, to });
    }
  },

  // ══════════════════════════════════════════════════════
  // PÁGINA WEB (landing)
  // ══════════════════════════════════════════════════════
  web: {
    ctaClicked(cta, section) {
      Analytics.track('web_cta_clicked', { cta, section });
    },
    sectionViewed(section) {
      Analytics.track('web_section_viewed', { section });
    },
    tabChanged(service) {
      Analytics.track('web_service_tab_changed', { service });
    },
    converterInteracted(amount, from, to) {
      Analytics.track('web_converter_interacted', { amount, from, to });
    },
    faqOpened(question) {
      Analytics.track('web_faq_opened', { question });
    }
  }
};

// Exportar para uso en módulos
if (typeof module !== 'undefined') module.exports = Analytics;
if (typeof window !== 'undefined') window.Analytics = Analytics;

// ══════════════════════════════════════════════════════
// AUTO-TRACKING DE LA LANDING PAGE
// Añadir este bloque al final del HTML
// ══════════════════════════════════════════════════════
/*
document.addEventListener('DOMContentLoaded', function() {

  // Track CTA clicks
  document.querySelectorAll('.btn-prim, .btn-out, .btn-nav').forEach(btn => {
    btn.addEventListener('click', () => {
      Analytics.web.ctaClicked(btn.textContent.trim(), btn.closest('section')?.id || 'nav');
    });
  });

  // Track service tabs
  document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
      Analytics.web.tabChanged(tab.textContent.trim());
    });
  });

  // Track FAQ opens
  document.querySelectorAll('.faq-q').forEach(q => {
    q.addEventListener('click', () => {
      Analytics.web.faqOpened(q.querySelector('span')?.textContent);
    });
  });

  // Track converter usage
  const cAmt = document.getElementById('cAmt');
  if (cAmt) {
    let debounce;
    cAmt.addEventListener('input', () => {
      clearTimeout(debounce);
      debounce = setTimeout(() => {
        const from = document.getElementById('cFrom')?.value;
        const to = document.getElementById('cTo')?.value;
        Analytics.web.converterInteracted(cAmt.value, from, to);
      }, 1000);
    });
  }

  // Track section views (Intersection Observer)
  const observer = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        Analytics.web.sectionViewed(e.target.id);
        observer.unobserve(e.target);
      }
    });
  }, { threshold: 0.5 });

  ['servicios','modelo','usuarios','traccion','representantes','impacto','roadmap'].forEach(id => {
    const el = document.getElementById(id);
    if (el) observer.observe(el);
  });
});
*/
