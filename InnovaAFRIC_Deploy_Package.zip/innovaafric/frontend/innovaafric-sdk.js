// ══════════════════════════════════════════════════════
// InnovaAFRIC · SDK de integración frontend ↔ API
// Usar en la app HTML o en React Native / Capacitor
//
// Uso básico:
//   import api from './innovaafric-sdk.js'
//   await api.auth.login(email, password)
//   const wallet = await api.wallet.get()
// ══════════════════════════════════════════════════════

const API_URL = window?.ENV_API_URL
  || import.meta?.env?.VITE_API_URL
  || 'https://api.innovaafric.com';

// ── TOKEN MANAGER ──────────────────────────────────────
const TokenManager = {
  get()      { return localStorage.getItem('ia_token') },
  set(t)     { localStorage.setItem('ia_token', t) },
  remove()   { localStorage.removeItem('ia_token') },
  user()     { const t = this.get(); if (!t) return null; try { return JSON.parse(atob(t.split('.')[1])) } catch { return null } }
};

// ── FETCH WRAPPER ──────────────────────────────────────
async function req(method, path, body = null, opts = {}) {
  const headers = { 'Content-Type': 'application/json' };
  const token = TokenManager.get();
  if (token) headers['Authorization'] = `Bearer ${token}`;

  const config = { method, headers };
  if (body) config.body = JSON.stringify(body);

  const res = await fetch(`${API_URL}${path}`, config);
  const data = await res.json().catch(() => ({}));

  // Auto-refresh token si expiró
  if (res.status === 401 && !opts.skipRefresh) {
    await api.auth.refresh().catch(() => api.auth.logout());
    return req(method, path, body, { skipRefresh: true });
  }

  if (!res.ok) throw Object.assign(new Error(data.error || 'Error de red'), { status: res.status, data });
  return data;
}

const get  = (path, params) => req('GET', params ? `${path}?${new URLSearchParams(params)}` : path);
const post = (path, body) => req('POST', path, body);
const put  = (path, body) => req('PUT', path, body);
const del  = (path) => req('DELETE', path);

// ══════════════════════════════════════════════════════
// API SDK — MÓDULOS
// ══════════════════════════════════════════════════════
const api = {

  // ── AUTH ──────────────────────────────────────────────
  auth: {
    async register(email, password, fullName, role, country, phone) {
      const data = await post('/auth/register', { email, password, full_name: fullName, role, country, phone });
      TokenManager.set(data.token);
      return data;
    },
    async login(email, password) {
      const data = await post('/auth/login', { email, password });
      TokenManager.set(data.token);
      return data;
    },
    async me() { return get('/auth/me') },
    async refresh() {
      const data = await post('/auth/refresh');
      TokenManager.set(data.token);
      return data;
    },
    logout() { TokenManager.remove(); window.location.href = '/' },
    isLoggedIn() { return !!TokenManager.get() },
    currentUser() { return TokenManager.user() }
  },

  // ── WALLET (XenderMoney) ──────────────────────────────
  wallet: {
    get()                          { return get('/wallet') },
    history(params)                { return get('/wallet/history', params) },
    rates()                        { return get('/wallet/rates') },

    send({ amount, currency, currencyRecv = 'XAF', recipientPhone, recipientId, description }) {
      return post('/wallet/send', { amount, currency, currency_recv: currencyRecv, recipient_phone: recipientPhone, recipient_id: recipientId, description });
    },
    p2p({ amount, currency = 'XAF', recipientId }) {
      return post('/wallet/p2p', { amount, currency, recipient_id: recipientId });
    },
    cashout({ amount, currency = 'EUR', method }) {
      return post('/wallet/cashout', { amount, currency, method });
    },
    qrPay({ merchantQr, amount, currency = 'XAF' }) {
      return post('/wallet/qr-pay', { merchant_qr: merchantQr, amount, currency });
    },

    // Envíos recurrentes
    getRecurring()  { return get('/wallet/recurring') },
    createRecurring(data) {
      return post('/wallet/recurring', {
        recipient_id: data.recipientId, recipient_phone: data.recipientPhone,
        amount: data.amount, currency: data.currency, currency_recv: data.currencyRecv,
        frequency: data.frequency, start_date: data.startDate
      });
    },
    deleteRecurring(id) { return del(`/wallet/recurring/${id}`) },

    // Calculadora local (sin llamada al API)
    calculate(amount, fromCurr, toCurr, fee = 0.02) {
      const RATES_LOCAL = {
        'EUR-XAF': 655.957, 'EUR-XOF': 655.957, 'EUR-USD': 1.08,
        'USD-XAF': 607.36, 'USD-EUR': 0.926
      };
      const rate = RATES_LOCAL[`${fromCurr}-${toCurr}`] || 1;
      const feeAmount = amount * fee;
      const received = (amount - feeAmount) * rate;
      const saved = amount * 0.10 - feeAmount;
      return { amount, feeAmount, received, rate, saved, fromCurr, toCurr };
    }
  },

  // ── XENDERSHOP ────────────────────────────────────────
  shop: {
    getProducts(params)          { return get('/shop/products', params) },
    getProduct(id)               { return get(`/shop/products/${id}`) },
    createOrder(items, currency, address) { return post('/shop/orders', { items, currency, delivery_address: address }) },
    getOrder(id)                 { return get(`/shop/orders/${id}`) },
    getTracking(orderId)         { return get(`/shop/orders/${orderId}/tracking`) },
    addReview(productId, rating, comment, orderId) {
      return post(`/shop/products/${productId}/review`, { rating, comment, order_id: orderId });
    },
    getFlashSales()              { return get('/shop/products', { flash: 'true', limit: 10 }) }
  },

  // ── XENDERBIGSHOP ─────────────────────────────────────
  bigshop: {
    getItems(params)             { return get('/bigshop/items', params) },
    createOrder(items, address, date, timeSlot) {
      return post('/bigshop/orders', { items, address, date, time_slot: timeSlot });
    }
  },

  // ── RIDERS ────────────────────────────────────────────
  rider: {
    getProfile()                 { return get('/riders/me') },
    getDeliveries()              { return get('/riders/me/deliveries') },
    getEarnings()                { return get('/riders/me/earnings') },
    updateDeliveryStatus(id, status, extras) {
      return put(`/riders/deliveries/${id}/status`, { status, ...extras });
    },
    setOnline(online)            { return put('/riders/me/online', { is_online: online }) }
  },

  // ── CIRCULARES ────────────────────────────────────────
  circular: {
    getProfile()                 { return get('/circular/me') },
    getRiders()                  { return get('/circular/me/riders') },
    getMerchants()               { return get('/circular/me/merchants') },
    getCommissions(month)        { return get('/circular/me/commissions', month ? { month } : undefined) },
    createMerchant(name, category, address) {
      return post('/circular/merchants', { name, category, address });
    }
  },

  // ── NOTIFICACIONES ────────────────────────────────────
  notifications: {
    get()                        { return get('/notifications') },
    readAll()                    { return put('/notifications/read-all') },
    read(id)                     { return put(`/notifications/${id}/read`) }
  },

  // ── PUNTOS Y REFERIDOS ────────────────────────────────
  points: {
    get()                        { return get('/points') },
    redeem(points, reward)       { return post('/points/redeem', { points, reward }) }
  },
  referrals: {
    get()                        { return get('/referrals') }
  },

  // ── ADMIN ─────────────────────────────────────────────
  admin: {
    getStats()                   { return get('/admin/stats') },
    getUsers(params)             { return get('/admin/users', params) }
  },

  // ── UTILIDADES ────────────────────────────────────────
  health()                       { return get('/health') }
};

export default api;

// ══════════════════════════════════════════════════════
// CÓMO USAR ESTE SDK EN LAS PANTALLAS HTML
// ══════════════════════════════════════════════════════
/*

EJEMPLO 1 — Login desde el modal de registro:

  import api from './innovaafric-sdk.js';

  async function handleLogin(email, password) {
    try {
      const { user, token } = await api.auth.login(email, password);
      console.log('Bienvenido', user.full_name);
      window.location.href = '/app';
    } catch (err) {
      alert(err.message); // "Credenciales incorrectas"
    }
  }


EJEMPLO 2 — Cargar saldo en la pantalla Home:

  async function loadHome() {
    const [wallet, notifications] = await Promise.all([
      api.wallet.get(),
      api.notifications.get()
    ]);

    document.getElementById('balance-eur').textContent =
      `€ ${wallet.eur.toFixed(2)}`;
    document.getElementById('notif-badge').textContent =
      notifications.unread;
  }


EJEMPLO 3 — Enviar dinero:

  async function sendMoney() {
    const calc = api.wallet.calculate(200, 'EUR', 'XAF'); // local, sin llamada
    // calc = { amount: 200, feeAmount: 4, received: 130591.4, ... }

    const { transaction } = await api.wallet.send({
      amount: 200,
      currency: 'EUR',
      currencyRecv: 'XAF',
      recipientPhone: '+237698765432',
      description: 'Envío familiar'
    });
    alert(`Enviado! Ref: ${transaction.ref_code}`);
  }


EJEMPLO 4 — Cargar productos del Shop con datos reales:

  async function loadShop(category) {
    const { data: products } = await api.shop.getProducts({ category, limit: 20 });
    const grid = document.getElementById('shopGrid');
    grid.innerHTML = products.map(p => `
      <div class="product-card" onclick="openProduct('${p.id}')">
        <img src="${p.images[0]}" alt="${p.name}">
        <h4>${p.name}</h4>
        <p>€${p.price_eur}</p>
        ${p.is_ce_certified ? '<span class="badge">CE ✓</span>' : ''}
      </div>
    `).join('');
  }


EJEMPLO 5 — Rider acepta y completa entrega:

  // Aceptar
  await api.rider.updateDeliveryStatus(deliveryId, 'picked_up');

  // Entregar con foto y firma
  await api.rider.updateDeliveryStatus(deliveryId, 'delivered', {
    photo_proof: base64PhotoUrl,
    signature_url: base64SignatureUrl
  });


EJEMPLO 6 — Dashboard admin en tiempo real:

  async function loadDashboard() {
    const stats = await api.admin.getStats();
    // stats = { users: 7100, transactions: 21000, revenue_eur: 148000, ... }
    Object.entries(stats).forEach(([key, val]) => {
      const el = document.querySelector(`[data-stat="${key}"]`);
      if (el) el.textContent = val.toLocaleString();
    });
  }
*/
